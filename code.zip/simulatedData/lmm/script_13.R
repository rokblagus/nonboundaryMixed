set.seed(13)
num_cluster =25
num_subj=20
sd_int=sqrt(0.1)
multiplier_int=0.5
rho=0.5
model="lmm"
source("../source_fun.R")