set.seed(16)
num_cluster =25
num_subj=20
sd_int=sqrt(0.1)
multiplier_int=1.5
rho=0.8
model="pois"
source("../source_fun.R")